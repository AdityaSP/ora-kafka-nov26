package com.kafka.learnings.one;

import org.apache.kafka.clients.producer.*;
import org.apache.kafka.common.serialization.StringSerializer;

import java.util.Properties;

/**
 * Created by Dell lap on 11/23/2018.
 */
public class ProducerDemoWithCallbackWithKeys {
    public static void main(String[] args) {
        System.out.println("Hello World!");
        // create producer properties
        Properties properties = new Properties();
        properties.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        properties.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "127.0.0.1:9092");
        properties.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());


        // create the producer
        KafkaProducer<String, String> producer =new KafkaProducer<String, String>(properties);

        // create a record

        // send data
        for(int i=0; i< 10 ; i++) {
            String key = "id_" + i;
            System.out.println("key to partition" + key + " " + key.hashCode() % 3);
            ProducerRecord<String, String> r =
                    new ProducerRecord<String, String>("first_topic", key,"Hello World!" + i);
            producer.send(r, new Callback() {
                public void onCompletion(RecordMetadata recordMetadata, Exception e) {
                    if (e==null){
                        System.out.println("Topic: " + recordMetadata.topic());
                        System.out.println("Partition: " + recordMetadata.partition());
                        System.out.println("Offset: " + recordMetadata.offset());
                        System.out.println("Timestamp: " + recordMetadata.timestamp());
                    }
                }
            });

            producer.flush();
        }
        producer.close();
    }

}
