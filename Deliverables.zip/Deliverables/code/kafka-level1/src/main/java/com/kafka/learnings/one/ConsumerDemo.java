package com.kafka.learnings.one;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.StringDeserializer;

import java.time.Duration;
import java.util.Arrays;
import java.util.Properties;

/**
 * Created by Dell lap on 11/24/2018.
 */
public class ConsumerDemo {
    public static void main(String[] args) throws InterruptedException {
        Properties props = new Properties();
        props.setProperty(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.setProperty(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
        props.setProperty(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, "10.30.3.30:9092");
        props.setProperty(ConsumerConfig.GROUP_ID_CONFIG, "tweet_group_nov27");
        props.setProperty(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
        props.setProperty(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, "false"); // disable auto commit of offsets
        props.setProperty(ConsumerConfig.MAX_POLL_RECORDS_CONFIG, "10");
        // create a consumer
        KafkaConsumer<String, String> consumer = new KafkaConsumer<String, String>(props);
        consumer.subscribe(Arrays.asList("twitter_tweets"));
        //TopicPartition partitionToReadFrom = new TopicPartition("nov27_topic", 1);

        while(true){
            //consumer.poll(100);
            boolean yes=false;
            ConsumerRecords<String, String> recs  = consumer.poll(Duration.ofMillis(100));
            for (ConsumerRecord<String, String> rec : recs){
                System.out.println( rec.partition() + ":" + rec.offset() );
                yes=true;
                Thread.sleep(1000);
            }
            if(yes) {
                System.out.println("Committing offsets...");
                consumer.commitSync();
            }
        }
    }
}
